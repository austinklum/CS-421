
public interface Comp {
	public Bool compare(Number value1, Number value2);
}
