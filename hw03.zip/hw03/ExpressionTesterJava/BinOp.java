
public interface BinOp {
	public Number apply(Number value1, Number value2);
}
