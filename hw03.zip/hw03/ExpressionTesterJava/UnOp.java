
public interface UnOp {
	public Number apply(Number value);
}
