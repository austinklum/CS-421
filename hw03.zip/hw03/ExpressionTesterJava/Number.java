
public interface Number extends NumExp {
	public double getValue();
}
