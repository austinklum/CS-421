
public interface NumExp extends Expression {
	public Number getNumber();
}
